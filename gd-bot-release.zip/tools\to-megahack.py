# Converts the bot's solutions to GDR replay files (.json) in the Downloads
# folder, for Mega Hack's Replay > Convert (.json, .gdr). Usage: python tools/to-megahack.py
import glob, json, os

SOLUTIONS = os.path.join(os.environ["LOCALAPPDATA"], "GeometryDash", "geode", "mods", "graspatje.bot-maker", "solutions")
REPLAYS = os.path.join(os.path.expanduser("~"), "Downloads")

for path in glob.glob(os.path.join(SOLUTIONS, "*.txt")):
    fields = dict(line.split(" ", 1) for line in open(path, encoding="utf-8").read().splitlines()[1:] if " " in line)
    per_block = int(fields["ticks-per-block"])
    blocks = fields["blocks"].strip()
    tail = fields.get("after-last-block", "released").strip() == "held"

    # One input per change between held and released, at 240 ticks per second
    inputs, held = [], False
    for i, block in enumerate(blocks + ("1" if tail else "0")):
        if (block == "1") != held:
            held = not held
            inputs.append({"frame": i * per_block, "btn": 1, "2p": False, "down": held})

    level_id = os.path.splitext(os.path.basename(path))[0]
    name = fields["level"].strip()
    replay = {
        "author": "gd-bot", "description": "", "duration": len(blocks) * per_block / 240.0,
        "gameVersion": 2.2081, "version": 1.0, "framerate": 240.0, "seed": 0, "coins": 0, "ldm": False,
        "bot": {"name": "gd-bot", "version": "0.1"},
        "level": {"id": int(level_id) if level_id.isdigit() else 0, "name": name},
        "inputs": inputs,
    }
    out = os.path.join(REPLAYS, f"{name} gd-bot.json")
    json.dump(replay, open(out, "w", encoding="utf-8"))
    print(f"{name}: {len(inputs)} inputs -> {out}")
